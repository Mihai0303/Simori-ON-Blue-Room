package Simori;
/**
 * @author Airidas Juskaitis, Ollie McLean, Nicholas Higgins, Mihai Bratosin,
 * Alonso-Lopez Mendoza
 */
public class Main {
		 
	public static void main(String[] args){
		GUI gui = new GUI();		
	}

}