package Simori;
/**
 * @author Airidas Juskaitis, Ollie McLean, Nicholas Higgins, Mihai Bratosin,
 * Alonso-Lopez Mendoza
 */
public enum ButtonText {
	ON, L1, L2, L3, L4, R1, R2, R3, R4, OK;
}
